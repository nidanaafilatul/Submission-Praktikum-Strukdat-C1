#ifndef boolean_H
#define boolean_H
/***********************************/
/* Program   : boolean.h */
/* Deskripsi : header file modul boolean */
/* NIM/Nama  : 24060121120039/ Nida' Naafilatul Haniifah*/
/* Tanggal   : 5 September 2022*/
/***********************************/

//type boolean macro bahasa C, false=0, true=1
#define false 0
#define true  1
#define boolean unsigned char

#endif

